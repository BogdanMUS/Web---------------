$(".btn").click(function () {
    $(".iframe").fadeToggle(100);
});

$(".btn3").click(function () {
    $(".iframe1").fadeToggle(100);
});
